/*
 * This file is part of SWAT: Elite Force Launcher
 *
 * SWAT: Elite Force Launcher is free software : you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SWAT: Elite Force Launcher is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SWAT: Elite Force Launcher. If not, see <http://www.gnu.org/licenses/>.
 */

#include <Windows.h>
#include <string>


///////////////////////////////////////////
//
// CommandLineToArgvA implementation
// Ripped from http://alter.org.ua/docs/win/args/
#ifndef CommandLineToArgvA
PCHAR*
CommandLineToArgvA(
	PCHAR CmdLine,
	int* _argc
)
{
	PCHAR* argv;
	PCHAR  _argv;
	ULONG   len;
	ULONG   argc;
	CHAR   a;
	ULONG   i, j;

	BOOLEAN  in_QM;
	BOOLEAN  in_TEXT;
	BOOLEAN  in_SPACE;

	len = strlen(CmdLine);
	i = ((len + 2) / 2) * sizeof(PVOID) + sizeof(PVOID);

	argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
		i + (len + 2) * sizeof(CHAR));

	_argv = (PCHAR)(((PUCHAR)argv) + i);

	argc = 0;
	argv[argc] = _argv;
	in_QM = FALSE;
	in_TEXT = FALSE;
	in_SPACE = TRUE;
	i = 0;
	j = 0;

	while (a = CmdLine[i]) {
		if (in_QM) {
			if (a == '\"') {
				in_QM = FALSE;
			}
			else {
				_argv[j] = a;
				j++;
			}
		}
		else {
			switch (a) {
			case '\"':
				in_QM = TRUE;
				in_TEXT = TRUE;
				if (in_SPACE) {
					argv[argc] = _argv + j;
					argc++;
				}
				in_SPACE = FALSE;
				break;
			case ' ':
			case '\t':
			case '\n':
			case '\r':
				if (in_TEXT) {
					_argv[j] = '\0';
					j++;
				}
				in_TEXT = FALSE;
				in_SPACE = TRUE;
				break;
			default:
				in_TEXT = TRUE;
				if (in_SPACE) {
					argv[argc] = _argv + j;
					argc++;
				}
				_argv[j] = a;
				j++;
				in_SPACE = FALSE;
				break;
			}
		}
		i++;
	}
	_argv[j] = '\0';
	argv[argc] = NULL;

	(*_argc) = argc;
	return argv;
}
#endif



//////////////////////////////////
//
// The main entrypoint of the program.
// Launches swat4x.exe with the proper context. Terminates when swat4x.exe is done running.
// Preconditions:
//	- This executable is located in the SEF folder.
//	- SWAT 4 and its expansion is installed correctly.
// Notes:
//	- All arguments will be concatenated into one long string.

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	PCHAR* argv;
	int argc;
	PROCESS_INFORMATION process{ 0 };
	STARTUPINFO startupInfo{ 0 };
	std::string processPath = "\"..\\..\\ContentExpansion\\System\\swat4x.exe\" ";
	char dirBuffer[1024]{ 0 };
	std::string dir;
	int out = 0;

	startupInfo.cb = sizeof(startupInfo);

	// FOR GAMERANGER: Append all of the arguments to the end so we can connect to the server properly.
	argv = CommandLineToArgvA(lpCmdLine, &argc);
	for (int i = 1; i < argc; i++)
	{
		processPath += argv[i];
	}

	// Get current directory and append /System to it so we launch from the SEF system folder.
	GetCurrentDirectory(1024, dirBuffer);
	dir = dirBuffer;
	dir += "\\..\\System";

	// If we clicked the Retry button from the error, go back to here
retry:
	BOOL result = CreateProcess(NULL, (LPSTR)processPath.c_str(),
		NULL, NULL, FALSE,
		NORMAL_PRIORITY_CLASS | CREATE_NO_WINDOW,		// Start without a command prompt window showing
		NULL,
		dir.c_str(),
		&startupInfo, &process);

	if (!result)
	{
		// Tell us what went wrong
		DWORD dwError = GetLastError();
		LPVOID lpMsgBuf;

		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, dwError,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR)&lpMsgBuf,
			0, NULL);

		DWORD msgPressed = MessageBox(NULL, (LPCSTR)lpMsgBuf, "SEF Launch Error",
			MB_ABORTRETRYIGNORE | MB_ICONERROR | MB_TASKMODAL);
		if (msgPressed == IDRETRY)
		{
			// If we pressed Retry, do that
			goto retry;
		}

		LocalFree(lpMsgBuf);
		out = 1;
	}
	else
	{
		DWORD exitCode;

		// Wait until the process has completed
		WaitForSingleObject(process.hProcess, INFINITE);

		result = GetExitCodeProcess(process.hProcess, &exitCode);

		// Close any remaining handles
		CloseHandle(process.hProcess);
		CloseHandle(process.hThread);

		if (!result)
		{
			// Died
			out = 1;
		}
		else
		{
			out = 0;
		}
	}

	GlobalFree(argv);
	return out;
}